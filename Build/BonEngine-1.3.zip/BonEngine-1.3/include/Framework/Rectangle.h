#pragma once

#include "RectangleF.h"
#include "RectangleI.h"
