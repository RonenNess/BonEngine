#pragma once

// register signals handler that log the signal before exit
void RegisterSignalsHandler();